'use client'
import Link from 'next/link'
import { useState, useEffect, useMemo } from "react";

// ── helpers ──────────────────────────────────────────────────────────────────
const fmt = (v) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v ?? 0);
const fmtDate = (s) => {
  if (!s) return "—";
  const [y, m, d] = s.split("-");
  return `${d}/${m}/${y}`;
};
const today = () => new Date().toISOString().split("T")[0];
const daysUntil = (s) => {
  if (!s) return null;
  const diff = new Date(s + "T12:00:00") - new Date();
  return Math.ceil(diff / 86400000);
};

const STATUS_LABEL = { pendente: "Pendente", pago: "Pago", vencido: "Vencido", recebido: "Recebido" };

const CATEGORIAS_PAGAR = ["Fornecedor", "Salário", "Aluguel", "Tarifa", "Imposto", "Marketing", "Outros"];
const CATEGORIAS_RECEBER = ["Venda DTF", "Serviço", "Adiantamento", "Outros"];
const FORMAS_PGTO = ["Pix", "Cartão Débito", "Cartão Crédito", "Dinheiro", "Boleto", "TED/DOC"];

const SEED = [
  { id: "s1", tipo: "pagar", descricao: "OKACHI - Insumos DTF", categoria: "Fornecedor", valor: 3200, vencimento: "2026-06-05", status: "pendente", forma: "Pix", obs: "" },
  { id: "s2", tipo: "pagar", descricao: "STARTINK - Filme e Tinta", categoria: "Fornecedor", valor: 2800, vencimento: "2026-06-08", status: "pendente", forma: "Pix", obs: "" },
  { id: "s3", tipo: "pagar", descricao: "Salário Funcionário 1", categoria: "Salário", valor: 1412, vencimento: "2026-06-05", status: "pendente", forma: "Pix", obs: "" },
  { id: "s4", tipo: "pagar", descricao: "Salário Funcionário 2", categoria: "Salário", valor: 1412, vencimento: "2026-06-05", status: "pendente", forma: "Pix", obs: "" },
  { id: "s5", tipo: "pagar", descricao: "DAS Simples Nacional", categoria: "Imposto", valor: 980, vencimento: "2026-06-20", status: "pendente", forma: "Boleto", obs: "Ref. Maio/2026" },
  { id: "s6", tipo: "receber", descricao: "Pedido HLSTORE MULTIMARCAS", categoria: "Venda DTF", valor: 840, vencimento: "2026-06-03", status: "pendente", forma: "Pix", obs: "30 un camiseta" },
  { id: "s7", tipo: "receber", descricao: "Pedido Grupo Rhinos", categoria: "Venda DTF", valor: 1200, vencimento: "2026-06-07", status: "pendente", forma: "Cartão Débito", obs: "" },
  { id: "s8", tipo: "receber", descricao: "Pedido OTAVIO FELIPE", categoria: "Venda DTF", valor: 420, vencimento: "2026-06-02", status: "recebido", forma: "Pix", obs: "" },
];

// ── storage helpers ───────────────────────────────────────────────────────────
const STORAGE_KEY = "pf_erp_lancamentos_v1";

async function loadData() {
  try {
    const r = await window.storage.get(STORAGE_KEY);
    if (r?.value) return JSON.parse(r.value);
  } catch (_) {}
  return SEED;
}

async function saveData(items) {
  try {
    await window.storage.set(STORAGE_KEY, JSON.stringify(items));
  } catch (_) {}
}

// ── empty form ────────────────────────────────────────────────────────────────
const emptyForm = (tipo = "pagar") => ({
  tipo,
  descricao: "",
  categoria: tipo === "pagar" ? "Fornecedor" : "Venda DTF",
  valor: "",
  vencimento: "",
  forma: "Pix",
  obs: "",
});

// ─────────────────────────────────────────────────────────────────────────────
export default function Page() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("dashboard"); // dashboard | pagar | receber
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm("pagar"));
  const [editId, setEditId] = useState(null);
  const [filtro, setFiltro] = useState("todos"); // todos | pendente | pago | vencido
  const [busca, setBusca] = useState("");
  const [toast, setToast] = useState(null);

  // load
  useEffect(() => {
    loadData().then((d) => { setItems(d); setLoading(false); });
  }, []);

  // save on change
  useEffect(() => {
    if (!loading) saveData(items);
  }, [items, loading]);

  // toast
  const showToast = (msg, tipo = "ok") => {
    setToast({ msg, tipo });
    setTimeout(() => setToast(null), 2800);
  };

  // computed
  const withStatus = useMemo(() =>
    items.map((i) => {
      if (i.status === "pago" || i.status === "recebido") return i;
      const d = daysUntil(i.vencimento);
      if (d !== null && d < 0) return { ...i, status: "vencido" };
      return i;
    }), [items]);

  const apagar = withStatus.filter((i) => i.tipo === "pagar");
  const areceber = withStatus.filter((i) => i.tipo === "receber");

  const totalPagar = apagar.filter((i) => i.status !== "pago").reduce((s, i) => s + i.valor, 0);
  const totalReceber = areceber.filter((i) => i.status !== "recebido").reduce((s, i) => s + i.valor, 0);
  const vencidos = withStatus.filter((i) => i.status === "vencido").length;
  const saldoPrev = totalReceber - totalPagar;

  const listTab = tab === "pagar" ? apagar : tab === "receber" ? areceber : [];
  const listFiltrada = listTab
    .filter((i) => filtro === "todos" || i.status === filtro)
    .filter((i) => !busca || i.descricao.toLowerCase().includes(busca.toLowerCase()) || i.categoria.toLowerCase().includes(busca.toLowerCase()))
    .sort((a, b) => (a.vencimento || "").localeCompare(b.vencimento || ""));

  // form handlers
  const openNew = (tipo) => {
    setForm(emptyForm(tipo));
    setEditId(null);
    setShowForm(true);
  };
  const openEdit = (item) => {
    setForm({ ...item });
    setEditId(item.id);
    setShowForm(true);
  };
  const closeForm = () => { setShowForm(false); setEditId(null); };

  const handleSave = () => {
    if (!form.descricao || !form.valor || !form.vencimento) {
      showToast("Preencha descrição, valor e vencimento.", "erro");
      return;
    }
    const novo = { ...form, valor: parseFloat(String(form.valor).replace(",", ".")), status: form.status || "pendente" };
    if (editId) {
      setItems((p) => p.map((i) => (i.id === editId ? { ...novo, id: editId } : i)));
      showToast("Lançamento atualizado ✓");
    } else {
      setItems((p) => [...p, { ...novo, id: "pf_" + Date.now() }]);
      showToast("Lançamento adicionado ✓");
    }
    closeForm();
  };

  const handlePagar = (id) => {
    setItems((p) => p.map((i) => i.id === id ? { ...i, status: i.tipo === "pagar" ? "pago" : "recebido" } : i));
    showToast(items.find(i => i.id === id)?.tipo === "pagar" ? "Marcado como pago ✓" : "Marcado como recebido ✓");
  };

  const handleDelete = (id) => {
    setItems((p) => p.filter((i) => i.id !== id));
    showToast("Removido.", "erro");
  };

  const cats = form.tipo === "pagar" ? CATEGORIAS_PAGAR : CATEGORIAS_RECEBER;

  // ── UI ──────────────────────────────────────────────────────────────────────
  const ACCENT = "#F97316"; // laranja
  const GREEN = "#22C55E";
  const RED = "#EF4444";
  const YELLOW = "#EAB308";

  const statusColor = (s) => ({ pendente: YELLOW, pago: GREEN, recebido: GREEN, vencido: RED }[s] || "#888");
  const statusBg = (s) => ({ pendente: "#fefce8", pago: "#f0fdf4", recebido: "#f0fdf4", vencido: "#fef2f2" }[s] || "#f5f5f5");

  if (loading) return (
    <div style={{ background: "#0c0c0f", minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <p style={{ color: ACCENT, fontFamily: "monospace", letterSpacing: 4 }}>CARREGANDO...</p>
    </div>
  );

  return (
    <div style={{ fontFamily: "'Outfit', sans-serif", background: "#0c0c0f", minHeight: "100vh", color: "#f0ede8" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Bebas+Neue&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 3px; }
        ::-webkit-scrollbar-thumb { background: #333; border-radius: 2px; }
        input, select, textarea { font-family: 'Outfit', sans-serif; }
        .glass { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; backdrop-filter: blur(8px); }
        .btn { border: none; border-radius: 8px; cursor: pointer; font-family: 'Outfit', sans-serif; font-weight: 600; font-size: 13px; transition: all 0.15s; }
        .btn:hover { transform: translateY(-1px); filter: brightness(1.1); }
        .btn:active { transform: translateY(0); }
        .nav-btn { background: none; border: none; cursor: pointer; font-family: 'Outfit', sans-serif; font-size: 13px; font-weight: 500; padding: 10px 16px; border-radius: 8px; transition: all 0.15s; color: #666; letter-spacing: 0.3px; }
        .nav-btn.active { background: rgba(249,115,22,0.15); color: #F97316; }
        .nav-btn:hover:not(.active) { background: rgba(255,255,255,0.05); color: #aaa; }
        .field-label { font-size: 11px; color: #555; letter-spacing: 1.5px; text-transform: uppercase; margin-bottom: 6px; }
        .field-input { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: #f0ede8; padding: 10px 14px; width: 100%; font-size: 14px; outline: none; transition: border 0.2s; }
        .field-input:focus { border-color: #F97316; }
        .field-input::placeholder { color: #444; }
        .field-input option { background: #1a1a1f; }
        .row { display: flex; align-items: center; gap: 14px; padding: 14px 18px; border-bottom: 1px solid rgba(255,255,255,0.04); transition: background 0.15s; cursor: pointer; }
        .row:hover { background: rgba(255,255,255,0.03); }
        .row:last-child { border-bottom: none; }
        @keyframes slideDown { from { opacity:0; transform:translateY(-12px); } to { opacity:1; transform:translateY(0); } }
        .slide-down { animation: slideDown 0.25s ease both; }
        @keyframes fadeUp { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }
        .fade-up { animation: fadeUp 0.35s ease both; }
        @keyframes toastIn { from { opacity:0; transform:translateX(40px); } to { opacity:1; transform:translateX(0); } }
        .toast { animation: toastIn 0.3s ease both; }
        .del-btn { opacity: 0; transition: opacity 0.15s; }
        .row:hover .del-btn { opacity: 1; }
      `}</style>

      {/* ── HEADER ── */}
      <div style={{ background: "linear-gradient(180deg, #141418 0%, #0c0c0f 100%)", borderBottom: "1px solid rgba(255,255,255,0.06)", padding: "0 24px", position: "sticky", top: 0, zIndex: 50 }}>
        <div style={{ maxWidth: 860, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", height: 58 }}>
          <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
            <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: 22, color: ACCENT, letterSpacing: 3 }}>PRINT</span>
            <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: 22, color: "#f0ede8", letterSpacing: 3 }}>FORNECE</span>
            <span style={{ fontSize: 10, color: "#444", letterSpacing: 2, marginLeft: 4 }}>ERP v1</span>
          </div>
          <nav style={{ display: "flex", gap: 2 }}>
            {[["dashboard","Dashboard"],["pagar","A Pagar"],["receber","A Receber"]].map(([id, label]) => (
              <button key={id} className={`nav-btn ${tab === id ? "active" : ""}`} onClick={() => { setTab(id); setShowForm(false); setBusca(""); setFiltro("todos"); }}>{label}</button>
            ))}
          </nav>
        </div>
      </div>

      {/* ── TOAST ── */}
      {toast && (
        <div className="toast" style={{ position: "fixed", top: 70, right: 20, zIndex: 999, background: toast.tipo === "erro" ? "#3a1010" : "#0f2a1a", border: `1px solid ${toast.tipo === "erro" ? RED : GREEN}`, borderRadius: 10, padding: "12px 18px", fontSize: 13, color: toast.tipo === "erro" ? "#fca5a5" : "#86efac", maxWidth: 280 }}>
          {toast.msg}
        </div>
      )}

      <div style={{ maxWidth: 860, margin: "0 auto", padding: "24px 20px 60px" }}>

        {/* ── DASHBOARD ── */}
        {tab === "dashboard" && (
          <div className="fade-up">
            {/* KPIs */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 12, marginBottom: 24 }}>
              {[
                { l: "A Receber", v: fmt(totalReceber), cor: GREEN, icon: "↓" },
                { l: "A Pagar", v: fmt(totalPagar), cor: RED, icon: "↑" },
                { l: "Saldo Previsto", v: fmt(saldoPrev), cor: saldoPrev >= 0 ? GREEN : RED, icon: "=" },
                { l: "Vencidos", v: vencidos, cor: vencidos > 0 ? RED : GREEN, icon: "!" },
              ].map(({ l, v, cor, icon }) => (
                <div key={l} className="glass" style={{ padding: "18px 16px", borderTop: `2px solid ${cor}30` }}>
                  <p style={{ fontSize: 9, color: "#444", letterSpacing: 2, textTransform: "uppercase", marginBottom: 10 }}>{l}</p>
                  <p style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: 26, color: cor, letterSpacing: 1 }}>{v}</p>
                </div>
              ))}
            </div>

            {/* Próximos vencimentos */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              {[
                { titulo: "⬆ Próximas saídas", lista: apagar.filter(i => i.status === "pendente").sort((a,b) => (a.vencimento||"").localeCompare(b.vencimento||"")).slice(0,5), cor: RED },
                { titulo: "⬇ Próximas entradas", lista: areceber.filter(i => i.status === "pendente").sort((a,b) => (a.vencimento||"").localeCompare(b.vencimento||"")).slice(0,5), cor: GREEN },
              ].map(({ titulo, lista, cor }) => (
                <div key={titulo} className="glass" style={{ padding: "18px 20px" }}>
                  <p style={{ fontSize: 12, color: "#555", letterSpacing: 1, marginBottom: 14 }}>{titulo}</p>
                  {lista.length === 0 && <p style={{ fontSize: 13, color: "#444" }}>Nenhum lançamento</p>}
                  {lista.map((i) => {
                    const d = daysUntil(i.vencimento);
                    return (
                      <div key={i.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                        <div>
                          <p style={{ fontSize: 13, fontWeight: 500 }}>{i.descricao}</p>
                          <p style={{ fontSize: 11, color: d !== null && d <= 2 ? RED : "#555", marginTop: 2 }}>
                            {d === 0 ? "Vence hoje" : d === 1 ? "Amanhã" : d !== null && d < 0 ? `Venceu há ${Math.abs(d)}d` : `em ${d}d · ${fmtDate(i.vencimento)}`}
                          </p>
                        </div>
                        <p style={{ fontSize: 14, fontWeight: 700, color: cor }}>{fmt(i.valor)}</p>
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── PAGAR / RECEBER ── */}
        {(tab === "pagar" || tab === "receber") && (
          <div className="fade-up">
            {/* toolbar */}
            <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap", alignItems: "center" }}>
              <input className="field-input" placeholder="Buscar..." value={busca} onChange={(e) => setBusca(e.target.value)} style={{ width: 200, fontSize: 13 }} />
              <select className="field-input" value={filtro} onChange={(e) => setFiltro(e.target.value)} style={{ width: "auto", fontSize: 13 }}>
                <option value="todos">Todos</option>
                <option value="pendente">Pendentes</option>
                {tab === "pagar" ? <option value="pago">Pagos</option> : <option value="recebido">Recebidos</option>}
                <option value="vencido">Vencidos</option>
              </select>
              <div style={{ flex: 1 }} />
              <button className="btn" onClick={() => openNew(tab === "pagar" ? "pagar" : "receber")} style={{ background: ACCENT, color: "#fff", padding: "10px 18px" }}>
                + Novo lançamento
              </button>
            </div>

            {/* form */}
            {showForm && (
              <div className="glass slide-down" style={{ padding: 20, marginBottom: 16, borderColor: "rgba(249,115,22,0.3)" }}>
                <p style={{ fontSize: 13, color: ACCENT, fontWeight: 600, marginBottom: 16, letterSpacing: 1 }}>
                  {editId ? "EDITAR" : "NOVO"} LANÇAMENTO — {form.tipo === "pagar" ? "A PAGAR" : "A RECEBER"}
                </p>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
                  <div style={{ gridColumn: "span 2" }}>
                    <p className="field-label">Descrição *</p>
                    <input className="field-input" placeholder="Ex: OKACHI — Insumos DTF" value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} />
                  </div>
                  <div>
                    <p className="field-label">Categoria</p>
                    <select className="field-input" value={form.categoria} onChange={(e) => setForm({ ...form, categoria: e.target.value })}>
                      {cats.map(c => <option key={c}>{c}</option>)}
                    </select>
                  </div>
                  <div>
                    <p className="field-label">Forma de Pagamento</p>
                    <select className="field-input" value={form.forma} onChange={(e) => setForm({ ...form, forma: e.target.value })}>
                      {FORMAS_PGTO.map(f => <option key={f}>{f}</option>)}
                    </select>
                  </div>
                  <div>
                    <p className="field-label">Valor (R$) *</p>
                    <input className="field-input" type="number" placeholder="0,00" value={form.valor} onChange={(e) => setForm({ ...form, valor: e.target.value })} />
                  </div>
                  <div>
                    <p className="field-label">Vencimento *</p>
                    <input className="field-input" type="date" value={form.vencimento} onChange={(e) => setForm({ ...form, vencimento: e.target.value })} />
                  </div>
                  <div style={{ gridColumn: "span 2" }}>
                    <p className="field-label">Observações</p>
                    <input className="field-input" placeholder="Opcional..." value={form.obs} onChange={(e) => setForm({ ...form, obs: e.target.value })} />
                  </div>
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                  <button className="btn" onClick={handleSave} style={{ background: ACCENT, color: "#fff", padding: "10px 22px" }}>Salvar</button>
                  <button className="btn" onClick={closeForm} style={{ background: "rgba(255,255,255,0.07)", color: "#888", padding: "10px 18px" }}>Cancelar</button>
                </div>
              </div>
            )}

            {/* sumário */}
            <div style={{ display: "flex", gap: 12, marginBottom: 14 }}>
              {tab === "pagar" ? (
                <>
                  <div className="glass" style={{ padding: "10px 16px", flex: 1 }}>
                    <p style={{ fontSize: 10, color: "#444", letterSpacing: 1 }}>EM ABERTO</p>
                    <p style={{ fontSize: 18, fontWeight: 700, color: RED }}>{fmt(apagar.filter(i=>i.status!=="pago").reduce((s,i)=>s+i.valor,0))}</p>
                  </div>
                  <div className="glass" style={{ padding: "10px 16px", flex: 1 }}>
                    <p style={{ fontSize: 10, color: "#444", letterSpacing: 1 }}>PAGOS</p>
                    <p style={{ fontSize: 18, fontWeight: 700, color: GREEN }}>{fmt(apagar.filter(i=>i.status==="pago").reduce((s,i)=>s+i.valor,0))}</p>
                  </div>
                  <div className="glass" style={{ padding: "10px 16px", flex: 1 }}>
                    <p style={{ fontSize: 10, color: "#444", letterSpacing: 1 }}>VENCIDOS</p>
                    <p style={{ fontSize: 18, fontWeight: 700, color: apagar.filter(i=>i.status==="vencido").length > 0 ? RED : "#444" }}>{apagar.filter(i=>i.status==="vencido").length}</p>
                  </div>
                </>
              ) : (
                <>
                  <div className="glass" style={{ padding: "10px 16px", flex: 1 }}>
                    <p style={{ fontSize: 10, color: "#444", letterSpacing: 1 }}>A RECEBER</p>
                    <p style={{ fontSize: 18, fontWeight: 700, color: GREEN }}>{fmt(areceber.filter(i=>i.status!=="recebido").reduce((s,i)=>s+i.valor,0))}</p>
                  </div>
                  <div className="glass" style={{ padding: "10px 16px", flex: 1 }}>
                    <p style={{ fontSize: 10, color: "#444", letterSpacing: 1 }}>RECEBIDOS</p>
                    <p style={{ fontSize: 18, fontWeight: 700, color: "#555" }}>{fmt(areceber.filter(i=>i.status==="recebido").reduce((s,i)=>s+i.valor,0))}</p>
                  </div>
                </>
              )}
            </div>

            {/* lista */}
            <div className="glass" style={{ overflow: "hidden" }}>
              {listFiltrada.length === 0 && (
                <p style={{ padding: 32, textAlign: "center", color: "#444", fontSize: 14 }}>Nenhum lançamento encontrado</p>
              )}
              {listFiltrada.map((item) => {
                const d = daysUntil(item.vencimento);
                const sc = statusColor(item.status);
                const sb = statusBg(item.status);
                const isPago = item.status === "pago" || item.status === "recebido";
                return (
                  <div key={item.id} className="row" onClick={() => openEdit(item)}>
                    {/* status dot */}
                    <div style={{ width: 8, height: 8, borderRadius: "50%", background: sc, flexShrink: 0, boxShadow: `0 0 6px ${sc}` }} />

                    {/* info */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 3 }}>
                        <p style={{ fontSize: 14, fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", opacity: isPago ? 0.4 : 1 }}>{item.descricao}</p>
                        {item.obs && <p style={{ fontSize: 11, color: "#444", flexShrink: 0 }}>· {item.obs}</p>}
                      </div>
                      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                        <span style={{ fontSize: 10, background: "rgba(255,255,255,0.06)", color: "#666", padding: "2px 8px", borderRadius: 20, letterSpacing: 0.5 }}>{item.categoria}</span>
                        <span style={{ fontSize: 10, color: "#444" }}>{item.forma}</span>
                        <span style={{ fontSize: 11, color: d !== null && d <= 1 && !isPago ? RED : "#444" }}>
                          {isPago ? fmtDate(item.vencimento) : d === 0 ? "⚡ Vence hoje" : d === 1 ? "⚡ Amanhã" : d !== null && d < 0 ? `⚠ Venceu ${Math.abs(d)}d atrás` : fmtDate(item.vencimento)}
                        </span>
                      </div>
                    </div>

                    {/* valor */}
                    <p style={{ fontSize: 16, fontWeight: 700, color: isPago ? "#444" : item.tipo === "pagar" ? RED : GREEN, flexShrink: 0, textDecoration: isPago ? "line-through" : "none" }}>
                      {fmt(item.valor)}
                    </p>

                    {/* ações */}
                    <div style={{ display: "flex", gap: 6, flexShrink: 0 }} onClick={(e) => e.stopPropagation()}>
                      {!isPago && (
                        <button className="btn" onClick={() => handlePagar(item.id)} style={{ background: "rgba(34,197,94,0.15)", color: GREEN, padding: "6px 12px", fontSize: 12 }}>
                          {item.tipo === "pagar" ? "Pagar" : "Receber"}
                        </button>
                      )}
                      <button className="btn del-btn" onClick={() => handleDelete(item.id)} style={{ background: "rgba(239,68,68,0.1)", color: RED, padding: "6px 10px", fontSize: 12 }}>✕</button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* ── bottom bar módulos futuros ── */}
      <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, background: "#0c0c0f", borderTop: "1px solid rgba(255,255,255,0.05)", padding: "8px 0" }}>
        <div style={{ maxWidth: 860, margin: "0 auto", display: "flex", justifyContent: "center", gap: 4 }}>
          {[
            { icon: "💰", label: "Financeiro", ativo: true },
            { icon: "🛒", label: "Caixa", ativo: false },
            { icon: "📦", label: "Estoque", ativo: false },
            { icon: "📋", label: "Pedidos", ativo: false },
            { icon: "👥", label: "Clientes", ativo: false },
          ].map(({ icon, label, ativo }) => (
            <div key={label} style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "4px 16px", borderRadius: 8, background: ativo ? "rgba(249,115,22,0.1)" : "transparent", cursor: ativo ? "default" : "not-allowed", opacity: ativo ? 1 : 0.3 }}>
              <span style={{ fontSize: 18 }}>{icon}</span>
              <p style={{ fontSize: 9, color: ativo ? ACCENT : "#555", letterSpacing: 1, marginTop: 2 }}>{label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
