'use client'
import Link from 'next/link'

const MODULOS = [
  { href: '/caixa',      icon: '🛒', label: 'Frente de Caixa',   desc: 'Registrar pedidos B2B',         pronto: true  },
  { href: '/financeiro', icon: '💰', label: 'Financeiro',         desc: 'Contas a pagar e receber',      pronto: true  },
  { href: '/estoque',    icon: '📦', label: 'Estoque',            desc: 'Controle de insumos DTF',       pronto: false },
  { href: '/pedidos',    icon: '📋', label: 'Pedidos',            desc: 'Fila de produção',              pronto: false },
  { href: '/clientes',   icon: '👥', label: 'Clientes',           desc: 'Histórico e recorrência',       pronto: false },
]

export default function Home() {
  return (
    <div style={{ minHeight: '100vh', background: '#0c0c0f', padding: '0 0 60px' }}>
      {/* header */}
      <div style={{ background: '#111115', borderBottom: '1px solid rgba(255,255,255,0.06)', padding: '28px 32px' }}>
        <p style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: 11, letterSpacing: 5, color: '#F97316', marginBottom: 6 }}>SISTEMA DE GESTÃO</p>
        <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: 36, letterSpacing: 3, color: '#fff' }}>
          PRINT <span style={{ color: '#F97316' }}>FORNECE</span>
        </h1>
        <p style={{ fontSize: 12, color: '#444', marginTop: 4 }}>DTF Têxtil · DTF UV · Camisa Lisa</p>
      </div>

      <div style={{ maxWidth: 700, margin: '0 auto', padding: '32px 20px' }}>
        <p style={{ fontSize: 11, color: '#444', letterSpacing: 3, textTransform: 'uppercase', marginBottom: 20 }}>Módulos</p>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          {MODULOS.map(({ href, icon, label, desc, pronto }) => (
            pronto ? (
              <Link key={href} href={href} style={{ textDecoration: 'none' }}>
                <div style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(249,115,22,0.2)', borderRadius: 12, padding: '22px 20px', cursor: 'pointer', transition: 'all 0.15s' }}>
                  <span style={{ fontSize: 28 }}>{icon}</span>
                  <p style={{ fontSize: 16, fontWeight: 700, color: '#f0ede8', marginTop: 10, marginBottom: 4 }}>{label}</p>
                  <p style={{ fontSize: 12, color: '#555' }}>{desc}</p>
                  <p style={{ fontSize: 10, color: '#F97316', marginTop: 8, letterSpacing: 1 }}>DISPONÍVEL →</p>
                </div>
              </Link>
            ) : (
              <div key={href} style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.05)', borderRadius: 12, padding: '22px 20px', opacity: 0.4 }}>
                <span style={{ fontSize: 28 }}>{icon}</span>
                <p style={{ fontSize: 16, fontWeight: 700, color: '#666', marginTop: 10, marginBottom: 4 }}>{label}</p>
                <p style={{ fontSize: 12, color: '#444' }}>{desc}</p>
                <p style={{ fontSize: 10, color: '#444', marginTop: 8, letterSpacing: 1 }}>EM BREVE</p>
              </div>
            )
          ))}
        </div>
      </div>
    </div>
  )
}
