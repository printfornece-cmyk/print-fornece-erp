'use client'
import Link from 'next/link'
import { useState, useEffect, useMemo, useRef } from "react";

const fmt = (v) => new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v ?? 0);
const fmtDate = (d) => d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" });
const fmtTime = (d) => d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
const genId = () => "pf_" + Date.now() + "_" + Math.random().toString(36).slice(2, 6);

const FORMAS = ["Pix", "Cartão Débito", "Cartão Crédito", "Dinheiro", "Boleto", "A Prazo"];
const FORMA_ICON = { "Pix": "⚡", "Cartão Débito": "💳", "Cartão Crédito": "💳", "Dinheiro": "💵", "Boleto": "🧾", "A Prazo": "📅" };

// ─── TABELA DTF TÊXTIL (metro linear 58cm) ───────────────────────────────────
// Faixas de metro inteiro: preço POR METRO, quantidade mínima 1m
const FAIXAS_METRO = [
  { min: 1,  max: 9,    preco: 49.90, label: "01 a 09 metros" },
  { min: 10, max: 29,   preco: 45.00, label: "10 a 29 metros"  },
  { min: 30, max: 49,   preco: 39.90, label: "30 a 49 metros"  },
  { min: 50, max: 99999,preco: 35.00, label: "50 ou mais metros"},
];

// Frações: preço FIXO por peça (não é por metro)
const FAIXAS_FRAC = [
  { id: "frac1", label: "Fração 0,20 a 0,45m", preco: 70.00 },
  { id: "frac2", label: "Fração 0,50 a 0,95m", preco: 60.00 },
];

// Dado metros inteiros (>=1), retorna preço/metro da faixa
const precoPorMetro = (m) => {
  const n = Math.floor(m); // faixa sempre por metro inteiro
  const f = FAIXAS_METRO.find(f => n >= f.min && n <= f.max);
  return f ? f.preco : 35.00;
};

const labelFaixa = (m) => {
  const n = Math.floor(m);
  const f = FAIXAS_METRO.find(f => n >= f.min && n <= f.max);
  return f ? f.label : "50 ou mais metros";
};

const PRODUTOS_SEED = [
  { id: "p1", nome: "DTF Têxtil — Metro Linear 58cm", preco: 49.90, unidade: "m",  categoria: "DTF Têxtil", tabelado: true },
  { id: "p2", nome: "DTF UV — 30cm × 50cm",           preco: 70.00, unidade: "un", categoria: "DTF UV"     },
  { id: "p3", nome: "Camisa Básica",                   preco: 25.00, unidade: "un", categoria: "Camisa Lisa"},
];

const CATEGORIAS = ["Todos", "DTF Têxtil", "DTF UV", "Camisa Lisa"];
const STORAGE_VENDAS = "pf_caixa_vendas_v2";
const STORAGE_PRODUTOS = "pf_caixa_produtos_v2";

async function load(key, fallback) {
  try { const r = await window.storage.get(key); if (r?.value) return JSON.parse(r.value); } catch (_) {}
  return fallback;
}
async function save(key, val) {
  try { await window.storage.set(key, JSON.stringify(val)); } catch (_) {}
}

export default function Page() {
  const [screen, setScreen] = useState("caixa");
  const [produtos, setProdutos] = useState([]);
  const [vendas, setVendas] = useState([]);
  const [loading, setLoading] = useState(true);

  const [carrinho, setCarrinho] = useState([]);
  const [clienteNome, setClienteNome] = useState("");
  const [busca, setBusca] = useState("");
  const [catFiltro, setCatFiltro] = useState("Todos");
  const [forma, setForma] = useState("Pix");
  const [dinheiroPago, setDinheiroPago] = useState("");
  const [desconto, setDesconto] = useState("");
  const [obs, setObs] = useState("");
  const [vencimento, setVencimento] = useState("");

  const [comprovante, setComprovante] = useState(null);
  const [produtoForm, setProdutoForm] = useState(null);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    Promise.all([load(STORAGE_PRODUTOS, PRODUTOS_SEED), load(STORAGE_VENDAS, [])]).then(([p, v]) => {
      setProdutos(p); setVendas(v); setLoading(false);
    });
  }, []);

  useEffect(() => { if (!loading) save(STORAGE_PRODUTOS, produtos); }, [produtos, loading]);
  useEffect(() => { if (!loading) save(STORAGE_VENDAS, vendas); }, [vendas, loading]);

  const showToast = (msg, tipo = "ok") => { setToast({ msg, tipo }); setTimeout(() => setToast(null), 2600); };

  const subtotal = carrinho.reduce((s, i) => {
    const preco = i.fracMode ? i.fracMode.preco : i.preco;
    return s + preco * i.qtd;
  }, 0);
  const descontoVal = parseFloat(desconto) || 0;
  const total = Math.max(0, subtotal - descontoVal);
  const troco = forma === "Dinheiro" && parseFloat(dinheiroPago) > 0 ? Math.max(0, parseFloat(dinheiroPago) - total) : 0;

  const addProduto = (p) => {
    setCarrinho((c) => {
      const ex = c.find((i) => i.id === p.id);
      if (ex) {
        if (ex.fracMode) return c; // fração não acumula pelo botão
        const novaQtd = ex.qtd + 1;
        return c.map((i) => i.id === p.id ? { ...i, qtd: novaQtd, qtdStr: String(novaQtd), preco: p.tabelado ? precoPorMetro(novaQtd) : p.preco } : i);
      }
      const preco = p.tabelado ? precoPorMetro(1) : p.preco;
      return [...c, { ...p, qtd: 1, qtdStr: "1", preco, fracMode: null }];
    });
    setBusca("");
  };

  const addLivre = () => {
    if (!busca.trim()) return;
    setCarrinho((c) => [...c, { id: genId(), nome: busca.trim(), preco: 0, qtd: 1, unidade: "un", livre: true }]);
    setBusca("");
  };

  // qtd como string enquanto digita, n como número validado
  const updateQtd = (id, val) => {
    const str = String(val).replace(",", ".");
    const n = parseFloat(str);
    setCarrinho((c) => c.map((i) => {
      if (i.id !== id) return i;
      if (i.fracMode) {
        // fração: qtd é número inteiro de peças
        const qtd = isNaN(n) || n < 1 ? i.qtd : Math.round(n);
        return { ...i, qtdStr: String(val), qtd };
      }
      // metros: aceita decimais, preço/m recalcula pela faixa
      const qtd = isNaN(n) || n <= 0 ? i.qtd : n;
      return { ...i, qtdStr: String(val), qtd, preco: i.tabelado ? precoPorMetro(qtd) : i.preco };
    }));
  };

  const setFracMode = (id, frac) => {
    setCarrinho((c) => c.map((i) => {
      if (i.id !== id) return i;
      if (!frac) {
        // volta para metros
        return { ...i, fracMode: null, qtd: 1, qtdStr: "1", preco: precoPorMetro(1) };
      }
      return { ...i, fracMode: frac, qtd: 1, qtdStr: "1", preco: frac.preco };
    }));
  };

  const updatePreco = (id, val) => setCarrinho((c) => c.map((i) => i.id === id ? { ...i, preco: parseFloat(val) || 0 } : i));
  const removeItem = (id) => setCarrinho((c) => c.filter((i) => i.id !== id));

  const finalizar = () => {
    if (carrinho.length === 0) { showToast("Adicione pelo menos um item.", "erro"); return; }
    if (total <= 0) { showToast("O total não pode ser zero.", "erro"); return; }
    if (!clienteNome.trim()) { showToast("Informe o nome do cliente (B2B).", "erro"); return; }
    if (forma === "Dinheiro" && parseFloat(dinheiroPago) < total) { showToast("Valor pago menor que o total.", "erro"); return; }

    const venda = {
      id: genId(), data: new Date().toISOString(),
      cliente: clienteNome, itens: [...carrinho],
      subtotal, desconto: descontoVal, total,
      forma, dinheiroPago: parseFloat(dinheiroPago) || 0, troco,
      obs, vencimento,
    };
    setVendas((v) => [venda, ...v]);
    setComprovante(venda);
    setCarrinho([]); setClienteNome(""); setDesconto(""); setDinheiroPago(""); setObs(""); setVencimento(""); setForma("Pix");
  };

  const produtosFiltrados = useMemo(() => {
    return produtos.filter((p) => {
      const buscaOk = !busca.trim() || p.nome.toLowerCase().includes(busca.toLowerCase());
      const catOk = catFiltro === "Todos" || p.categoria === catFiltro;
      return buscaOk && catOk;
    });
  }, [busca, catFiltro, produtos]);

  const hoje = new Date().toDateString();
  const vendasHoje = vendas.filter((v) => new Date(v.data).toDateString() === hoje);
  const totalHoje = vendasHoje.reduce((s, v) => s + v.total, 0);

  const salvarProduto = () => {
    if (!produtoForm?.nome || !produtoForm?.preco) { showToast("Nome e preço são obrigatórios.", "erro"); return; }
    const item = { ...produtoForm, preco: parseFloat(produtoForm.preco), categoria: produtoForm.categoria || "DTF Têxtil" };
    if (produtoForm.id) setProdutos((p) => p.map((x) => x.id === produtoForm.id ? item : x));
    else setProdutos((p) => [...p, { ...item, id: genId() }]);
    setProdutoForm(null); showToast("Produto salvo ✓");
  };

  const enviarWhatsApp = (v) => {
    const d = new Date(v.data);
    let txt = `*🧾 Pedido — Print Fornece*\n`;
    txt += `📅 ${fmtDate(d)} às ${fmtTime(d)}\n`;
    txt += `🏢 *${v.cliente}*\n\n`;
    txt += `*Itens:*\n`;
    v.itens.forEach((i) => { txt += `• ${i.qtd}${i.unidade} × ${i.nome} — ${fmt(i.preco * i.qtd)}\n`; });
    txt += `\n*Subtotal:* ${fmt(v.subtotal)}`;
    if (v.desconto > 0) txt += `\n*Desconto:* -${fmt(v.desconto)}`;
    txt += `\n*Total:* ${fmt(v.total)}`;
    txt += `\n*Pagamento:* ${v.forma}`;
    if (v.vencimento) txt += `\n*Vencimento:* ${v.vencimento}`;
    if (v.troco > 0) txt += `\n*Troco:* ${fmt(v.troco)}`;
    if (v.obs) txt += `\n*Obs:* ${v.obs}`;
    txt += `\n\n_Print Fornece · DTF Têxtil · DTF UV · Camisa Lisa_ 🖨️`;
    window.open(`https://wa.me/?text=${encodeURIComponent(txt)}`, "_blank");
  };

  const ACCENT = "#F97316"; const GREEN = "#22C55E"; const RED = "#EF4444";
  const CAT_COR = { "DTF Têxtil": "#7C3AED", "DTF UV": "#0EA5E9", "Camisa Lisa": "#F59E0B" };

  if (loading) return <div style={{ background: "#0c0c0f", minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}><p style={{ color: ACCENT, fontFamily: "monospace", letterSpacing: 4 }}>CARREGANDO...</p></div>;

  return (
    <div style={{ fontFamily: "'Outfit', sans-serif", background: "#0c0c0f", minHeight: "100vh", color: "#f0ede8" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Bebas+Neue&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 3px; } ::-webkit-scrollbar-thumb { background: #2a2a2a; border-radius: 2px; }
        .glass { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; }
        .btn { border: none; border-radius: 8px; cursor: pointer; font-family: 'Outfit', sans-serif; font-weight: 600; font-size: 13px; transition: all 0.15s; }
        .btn:hover { transform: translateY(-1px); filter: brightness(1.1); }
        .nav { background: none; border: none; cursor: pointer; font-family: 'Outfit', sans-serif; font-size: 12px; font-weight: 500; padding: 9px 16px; border-radius: 8px; transition: all 0.15s; color: #555; letter-spacing: 0.5px; }
        .nav.active { background: rgba(249,115,22,0.15); color: #F97316; }
        .nav:hover:not(.active) { background: rgba(255,255,255,0.05); color: #aaa; }
        .field { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.09); border-radius: 8px; color: #f0ede8; padding: 10px 14px; width: 100%; font-size: 14px; outline: none; font-family: 'Outfit',sans-serif; transition: border 0.2s; }
        .field:focus { border-color: #F97316; }
        .field::placeholder { color: #383838; }
        .field option { background: #1a1a1f; }
        .prod-btn { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.07); border-radius: 10px; padding: 10px 12px; cursor: pointer; transition: all 0.15s; text-align: left; width: 100%; }
        .prod-btn:hover { background: rgba(249,115,22,0.08); border-color: rgba(249,115,22,0.25); }
        .cat-btn { background: none; border: 1px solid rgba(255,255,255,0.08); border-radius: 20px; padding: 5px 14px; cursor: pointer; font-family:'Outfit',sans-serif; font-size: 11px; font-weight: 500; color: #555; transition: all 0.15s; }
        .cat-btn.sel { background: rgba(249,115,22,0.15); border-color: #F97316; color: #F97316; }
        .forma-btn { border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 8px 10px; cursor: pointer; font-family:'Outfit',sans-serif; font-size: 11px; font-weight: 500; transition: all 0.15s; background: transparent; color: #555; }
        .forma-btn.sel { background: rgba(249,115,22,0.15); border-color: #F97316; color: #F97316; }
        @keyframes fadeUp { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }
        .fu { animation: fadeUp 0.3s ease both; }
        @keyframes scaleIn { from { opacity:0; transform:scale(0.93); } to { opacity:1; transform:scale(1); } }
        .scale-in { animation: scaleIn 0.22s ease both; }
        @keyframes toastIn { from { opacity:0; transform:translateX(40px); } to { opacity:1; transform:translateX(0); } }
        .toast-anim { animation: toastIn 0.3s ease both; }
      `}</style>

      {/* HEADER */}
      <div style={{ background: "#111115", borderBottom: "1px solid rgba(255,255,255,0.06)", padding: "0 20px", position: "sticky", top: 0, zIndex: 50 }}>
        <div style={{ maxWidth: 940, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", height: 54 }}>
          <div style={{ display: "flex", alignItems: "baseline", gap: 6 }}>
            <span style={{ fontFamily: "'Bebas Neue'", fontSize: 20, color: ACCENT, letterSpacing: 3 }}>PRINT</span>
            <span style={{ fontFamily: "'Bebas Neue'", fontSize: 20, color: "#f0ede8", letterSpacing: 3 }}>FORNECE</span>
            <span style={{ fontSize: 10, color: "#333", letterSpacing: 2, marginLeft: 4 }}>CAIXA B2B</span>
          </div>
          <nav style={{ display: "flex", gap: 2 }}>
            {[["caixa","🛒 Pedido"],["historico","📋 Vendas"],["produtos","📦 Produtos"]].map(([id, label]) => (
              <button key={id} className={`nav ${screen === id ? "active" : ""}`} onClick={() => setScreen(id)}>{label}</button>
            ))}
          </nav>
        </div>
      </div>

      {/* TOAST */}
      {toast && (
        <div className="toast-anim" style={{ position: "fixed", top: 64, right: 16, zIndex: 999, background: toast.tipo === "erro" ? "#2a0f0f" : "#0f2a1a", border: `1px solid ${toast.tipo === "erro" ? RED : GREEN}40`, borderRadius: 10, padding: "11px 16px", fontSize: 13, color: toast.tipo === "erro" ? "#fca5a5" : "#86efac" }}>
          {toast.msg}
        </div>
      )}

      {/* MODAL COMPROVANTE */}
      {comprovante && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.88)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
          <div className="scale-in" style={{ background: "#141418", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 16, padding: "26px 22px", width: "100%", maxWidth: 400, maxHeight: "90vh", overflowY: "auto" }}>
            <div style={{ textAlign: "center", marginBottom: 18 }}>
              <p style={{ fontFamily: "'Bebas Neue'", fontSize: 22, color: ACCENT, letterSpacing: 4 }}>PRINT FORNECE</p>
              <p style={{ fontSize: 10, color: "#333", letterSpacing: 3 }}>DTF TÊXTIL · DTF UV · CAMISA LISA</p>
              <div style={{ height: 1, background: "rgba(255,255,255,0.06)", margin: "12px 0" }} />
              <p style={{ fontSize: 12, color: "#555" }}>{fmtDate(new Date(comprovante.data))} às {fmtTime(new Date(comprovante.data))}</p>
              <p style={{ fontSize: 16, fontWeight: 700, marginTop: 4 }}>🏢 {comprovante.cliente}</p>
            </div>

            <div style={{ marginBottom: 14 }}>
              {comprovante.itens.map((i) => (
                <div key={i.id} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", borderBottom: "1px solid rgba(255,255,255,0.04)", fontSize: 13 }}>
                  <p style={{ color: "#aaa" }}>{i.qtd}{i.unidade} × {i.nome}</p>
                  <p style={{ color: "#f0ede8", fontWeight: 500 }}>{fmt(i.preco * i.qtd)}</p>
                </div>
              ))}
            </div>

            <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 8, padding: "12px 14px", marginBottom: 14 }}>
              {comprovante.desconto > 0 && <>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "#555", marginBottom: 5 }}><p>Subtotal</p><p>{fmt(comprovante.subtotal)}</p></div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: RED, marginBottom: 6 }}><p>Desconto</p><p>-{fmt(comprovante.desconto)}</p></div>
              </>}
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 18, fontWeight: 700 }}><p>Total</p><p style={{ color: GREEN }}>{fmt(comprovante.total)}</p></div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "#555", marginTop: 8 }}>
                <p>{FORMA_ICON[comprovante.forma]} {comprovante.forma}</p>
                {comprovante.vencimento && <p style={{ color: ACCENT }}>Venc. {comprovante.vencimento}</p>}
                {comprovante.troco > 0 && <p style={{ color: ACCENT }}>Troco {fmt(comprovante.troco)}</p>}
              </div>
            </div>
            {comprovante.obs && <p style={{ fontSize: 12, color: "#555", marginBottom: 14 }}>📝 {comprovante.obs}</p>}
            <div style={{ textAlign: "center", fontSize: 10, color: "#2a2a2a", letterSpacing: 2, marginBottom: 18 }}>✦ PRINT FORNECE — OBRIGADO ✦</div>
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn" onClick={() => enviarWhatsApp(comprovante)} style={{ flex: 1, background: "#25D366", color: "#fff", padding: "12px 0", fontSize: 14 }}>📲 WhatsApp</button>
              <button className="btn" onClick={() => window.print()} style={{ background: "rgba(255,255,255,0.07)", color: "#aaa", padding: "12px 14px" }}>🖨️</button>
              <button className="btn" onClick={() => setComprovante(null)} style={{ background: "rgba(255,255,255,0.07)", color: "#aaa", padding: "12px 14px" }}>✕</button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL PRODUTO */}
      {produtoForm !== null && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.82)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
          <div className="scale-in" style={{ background: "#141418", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 14, padding: "24px 22px", width: "100%", maxWidth: 380 }}>
            <p style={{ fontSize: 13, fontWeight: 600, color: ACCENT, marginBottom: 18, letterSpacing: 1 }}>{produtoForm.id ? "EDITAR" : "NOVO"} PRODUTO</p>
            {[
              { label: "Nome", key: "nome", placeholder: "Ex: DTF Têxtil — Metro Linear" },
              { label: "Preço (R$)", key: "preco", placeholder: "0,00", type: "number" },
              { label: "Unidade", key: "unidade", placeholder: "m, un, rolo, kit, m²..." },
            ].map(({ label, key, placeholder, type }) => (
              <div key={key} style={{ marginBottom: 13 }}>
                <p style={{ fontSize: 10, color: "#555", letterSpacing: 2, textTransform: "uppercase", marginBottom: 5 }}>{label}</p>
                <input className="field" type={type || "text"} placeholder={placeholder} value={produtoForm[key] || ""} onChange={(e) => setProdutoForm({ ...produtoForm, [key]: e.target.value })} />
              </div>
            ))}
            <div style={{ marginBottom: 16 }}>
              <p style={{ fontSize: 10, color: "#555", letterSpacing: 2, textTransform: "uppercase", marginBottom: 5 }}>Categoria</p>
              <select className="field" value={produtoForm.categoria || "DTF Têxtil"} onChange={(e) => setProdutoForm({ ...produtoForm, categoria: e.target.value })}>
                {["DTF Têxtil","DTF UV","Camisa Lisa"].map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn" onClick={salvarProduto} style={{ background: ACCENT, color: "#fff", padding: "11px 0", flex: 1 }}>Salvar</button>
              <button className="btn" onClick={() => setProdutoForm(null)} style={{ background: "rgba(255,255,255,0.07)", color: "#888", padding: "11px 16px" }}>Cancelar</button>
            </div>
          </div>
        </div>
      )}

      <div style={{ maxWidth: 940, margin: "0 auto", padding: "20px 16px 80px" }}>

        {/* ══ CAIXA ══ */}
        {screen === "caixa" && (
          <div className="fu" style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 16, alignItems: "start" }}>
            {/* esquerdo */}
            <div>
              {/* cliente — obrigatório em B2B */}
              <div style={{ marginBottom: 12 }}>
                <p style={{ fontSize: 10, color: "#555", letterSpacing: 2, textTransform: "uppercase", marginBottom: 5 }}>Cliente / Empresa *</p>
                <input className="field" placeholder="Nome da empresa ou cliente..." value={clienteNome} onChange={(e) => setClienteNome(e.target.value)} />
              </div>

              {/* busca + filtro categoria */}
              <div style={{ display: "flex", gap: 8, marginBottom: 10, alignItems: "center" }}>
                <div style={{ flex: 1, position: "relative" }}>
                  <input className="field" placeholder="🔍  Buscar produto ou item livre..." value={busca} onChange={(e) => setBusca(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter" && produtosFiltrados.length === 0 && busca.trim()) addLivre(); }} style={{ fontSize: 13 }} />
                  {busca && produtosFiltrados.length === 0 && (
                    <button className="btn" onClick={addLivre} style={{ position: "absolute", right: 6, top: 6, background: ACCENT, color: "#fff", padding: "5px 12px", fontSize: 11 }}>+ Livre</button>
                  )}
                </div>
              </div>
              <div style={{ display: "flex", gap: 6, marginBottom: 12, flexWrap: "wrap" }}>
                {CATEGORIAS.map((c) => (
                  <button key={c} className={`cat-btn ${catFiltro === c ? "sel" : ""}`} onClick={() => setCatFiltro(c)}>{c}</button>
                ))}
              </div>

              {/* grade produtos */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
                {produtosFiltrados.map((p) => (
                  <button key={p.id} className="prod-btn" onClick={() => addProduto(p)}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 6 }}>
                      <span style={{ fontSize: 9, background: (CAT_COR[p.categoria] || "#555") + "20", color: CAT_COR[p.categoria] || "#888", padding: "2px 7px", borderRadius: 20, letterSpacing: 0.5, fontWeight: 600 }}>{p.categoria}</span>
                    </div>
                    <p style={{ fontSize: 12, fontWeight: 500, color: "#ccc", marginBottom: 6, lineHeight: 1.3 }}>{p.nome}</p>
                    {p.tabelado
                      ? <p style={{ fontSize: 11, color: GREEN }}>a partir de {fmt(35.00)}/m</p>
                      : <p style={{ fontSize: 16, fontWeight: 700, color: ACCENT }}>{fmt(p.preco)}<span style={{ fontSize: 10, color: "#444", marginLeft: 3 }}>/{p.unidade}</span></p>
                    }
                  </button>
                ))}
              </div>

              {/* tabela de preços DTF Têxtil */}
              {(catFiltro === "Todos" || catFiltro === "DTF Têxtil") && (
                <div style={{ marginTop: 14, background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 10, padding: "14px 16px" }}>
                  <p style={{ fontSize: 10, color: "#7C3AED", letterSpacing: 3, textTransform: "uppercase", marginBottom: 12, fontWeight: 600 }}>Tabela DTF Têxtil — Metro Linear 58cm</p>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginBottom: 10 }}>
                    {FAIXAS_METRO.map((f) => (
                      <div key={f.label} style={{ display: "flex", justifyContent: "space-between", background: "rgba(124,58,237,0.08)", borderRadius: 7, padding: "8px 12px", border: "1px solid rgba(124,58,237,0.15)" }}>
                        <p style={{ fontSize: 12, color: "#aaa" }}>{f.label}</p>
                        <p style={{ fontSize: 13, fontWeight: 700, color: ACCENT }}>R$ {f.preco.toFixed(2).replace(".", ",")}/m</p>
                      </div>
                    ))}
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
                    {FAIXAS_FRAC.map((f) => (
                      <div key={f.id} style={{ display: "flex", justifyContent: "space-between", background: "rgba(255,255,255,0.03)", borderRadius: 7, padding: "7px 12px", border: "1px solid rgba(255,255,255,0.06)" }}>
                        <p style={{ fontSize: 11, color: "#666" }}>{f.label}</p>
                        <p style={{ fontSize: 12, fontWeight: 600, color: "#888" }}>R$ {f.preco.toFixed(2).replace(".", ",")}</p>
                      </div>
                    ))}
                  </div>
                  <p style={{ fontSize: 10, color: "#444", marginTop: 10 }}>⏱ Prazo até 12h · Pagamento Pix ou Débito</p>
                </div>
              )}

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 14 }}>
                <div>
                  <p style={{ fontSize: 10, color: "#555", letterSpacing: 2, textTransform: "uppercase", marginBottom: 5 }}>Observação</p>
                  <input className="field" placeholder="Prazo, ref. do pedido..." value={obs} onChange={(e) => setObs(e.target.value)} />
                </div>
                {(forma === "A Prazo" || forma === "Boleto") && (
                  <div>
                    <p style={{ fontSize: 10, color: "#555", letterSpacing: 2, textTransform: "uppercase", marginBottom: 5 }}>Vencimento</p>
                    <input className="field" type="date" value={vencimento} onChange={(e) => setVencimento(e.target.value)} />
                  </div>
                )}
              </div>
            </div>

            {/* carrinho */}
            <div className="glass" style={{ padding: "18px 16px", position: "sticky", top: 70 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                <p style={{ fontSize: 11, color: "#555", letterSpacing: 2, textTransform: "uppercase" }}>Pedido</p>
                {carrinho.length > 0 && <button className="btn" onClick={() => setCarrinho([])} style={{ background: "rgba(239,68,68,0.1)", color: RED, padding: "4px 10px", fontSize: 11 }}>Limpar</button>}
              </div>

              {carrinho.length === 0 && <p style={{ fontSize: 13, color: "#2a2a2a", textAlign: "center", padding: "28px 0" }}>Nenhum item</p>}
              <div style={{ maxHeight: 260, overflowY: "auto", marginBottom: 12 }}>
                {carrinho.map((item) => (
                  <div key={item.id} style={{ padding: "8px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                      <div style={{ flex: 1, marginRight: 8 }}>
                        <p style={{ fontSize: 12, fontWeight: 500 }}>{item.nome}</p>
                        {item.tabelado && (
                          <p style={{ fontSize: 10, color: GREEN, marginTop: 2 }}>
                            {item.fracMode
                              ? `${item.fracMode.label} · ${fmt(item.fracMode.preco)}/peça`
                              : `📊 ${labelFaixa(item.qtd)} · ${fmt(item.preco)}/m`}
                          </p>
                        )}
                      </div>
                      <button className="btn" onClick={() => removeItem(item.id)} style={{ background: "none", color: "#333", padding: 0, fontSize: 13 }}>✕</button>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      {item.tabelado ? (
                        <div style={{ flex: 1 }}>
                          {/* seletor de modo */}
                          <div style={{ display: "flex", gap: 4, marginBottom: 6, flexWrap: "wrap" }}>
                            <button onClick={() => setFracMode(item.id, null)} style={{ fontSize: 10, padding: "3px 10px", borderRadius: 20, border: "1px solid", cursor: "pointer", fontFamily: "Outfit,sans-serif", background: !item.fracMode ? "rgba(124,58,237,0.2)" : "transparent", borderColor: !item.fracMode ? "#7C3AED" : "rgba(255,255,255,0.1)", color: !item.fracMode ? "#a78bfa" : "#555" }}>
                              Metros inteiros
                            </button>
                            {FAIXAS_FRAC.map((f) => (
                              <button key={f.id} onClick={() => setFracMode(item.id, f)} style={{ fontSize: 10, padding: "3px 10px", borderRadius: 20, border: "1px solid", cursor: "pointer", fontFamily: "Outfit,sans-serif", background: item.fracMode?.id === f.id ? "rgba(249,115,22,0.2)" : "transparent", borderColor: item.fracMode?.id === f.id ? ACCENT : "rgba(255,255,255,0.1)", color: item.fracMode?.id === f.id ? ACCENT : "#555", whiteSpace: "nowrap" }}>
                                {f.label} — {fmt(f.preco)}
                              </button>
                            ))}
                          </div>
                          {!item.fracMode ? (
                            // metros: input livre decimal, preço/m muda pela faixa
                            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                              <button className="btn" onClick={() => updateQtd(item.id, Math.max(1, item.qtd - 1))} style={{ background: "rgba(255,255,255,0.06)", color: "#888", width: 26, height: 26, padding: 0, fontSize: 14 }}>−</button>
                              <input
                                type="text"
                                inputMode="decimal"
                                value={item.qtdStr !== undefined ? item.qtdStr : String(item.qtd)}
                                onChange={(e) => updateQtd(item.id, e.target.value)}
                                onBlur={(e) => {
                                  const n = parseFloat(String(e.target.value).replace(",", "."));
                                  updateQtd(item.id, isNaN(n) || n <= 0 ? 1 : n);
                                }}
                                style={{ width: 58, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 6, color: "#f0ede8", fontSize: 13, textAlign: "center", padding: "4px 0", fontFamily: "Outfit,sans-serif", outline: "none" }}
                              />
                              <button className="btn" onClick={() => updateQtd(item.id, item.qtd + 1)} style={{ background: "rgba(255,255,255,0.06)", color: "#aaa", width: 26, height: 26, padding: 0, fontSize: 14 }}>+</button>
                              <span style={{ fontSize: 11, color: "#555" }}>m</span>
                              <p style={{ flex: 1, fontSize: 14, fontWeight: 700, color: "#f0ede8", textAlign: "right" }}>{fmt(item.preco * item.qtd)}</p>
                            </div>
                          ) : (
                            // fração: preço fixo, qtd = número de peças
                            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                              <button className="btn" onClick={() => updateQtd(item.id, Math.max(1, item.qtd - 1))} style={{ background: "rgba(255,255,255,0.06)", color: "#888", width: 26, height: 26, padding: 0, fontSize: 14 }}>−</button>
                              <input
                                type="text"
                                inputMode="numeric"
                                value={item.qtdStr !== undefined ? item.qtdStr : String(item.qtd)}
                                onChange={(e) => updateQtd(item.id, e.target.value)}
                                style={{ width: 58, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 6, color: "#f0ede8", fontSize: 13, textAlign: "center", padding: "4px 0", fontFamily: "Outfit,sans-serif", outline: "none" }}
                              />
                              <button className="btn" onClick={() => updateQtd(item.id, item.qtd + 1)} style={{ background: "rgba(255,255,255,0.06)", color: "#aaa", width: 26, height: 26, padding: 0, fontSize: 14 }}>+</button>
                              <span style={{ fontSize: 11, color: "#555" }}>un</span>
                              <p style={{ flex: 1, fontSize: 14, fontWeight: 700, color: "#f0ede8", textAlign: "right" }}>{fmt(item.fracMode.preco * item.qtd)}</p>
                            </div>
                          )}
                        </div>
                      ) : (
                        // produto normal (DTF UV, Camisa)
                        <div style={{ display: "flex", alignItems: "center", gap: 6, flex: 1 }}>
                          <button className="btn" onClick={() => updateQtd(item.id, Math.max(1, item.qtd - 1))} style={{ background: "rgba(255,255,255,0.06)", color: "#888", width: 26, height: 26, padding: 0, fontSize: 14 }}>−</button>
                          <input type="text" inputMode="numeric" value={item.qtdStr !== undefined ? item.qtdStr : String(item.qtd)} onChange={(e) => updateQtd(item.id, e.target.value)} style={{ width: 52, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 6, color: "#f0ede8", fontSize: 13, textAlign: "center", padding: "4px 0", fontFamily: "Outfit,sans-serif", outline: "none" }} />
                          <button className="btn" onClick={() => updateQtd(item.id, item.qtd + 1)} style={{ background: "rgba(255,255,255,0.06)", color: "#aaa", width: 26, height: 26, padding: 0, fontSize: 14 }}>+</button>
                          <span style={{ fontSize: 11, color: "#555" }}>{item.unidade}</span>
                          {item.livre
                            ? <input type="text" inputMode="decimal" placeholder="R$" value={item.preco || ""} onChange={(e) => updatePreco(item.id, e.target.value)} style={{ flex: 1, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 6, color: ACCENT, fontSize: 12, padding: "3px 8px", fontFamily: "Outfit,sans-serif", outline: "none" }} />
                            : <p style={{ flex: 1, fontSize: 14, fontWeight: 700, color: "#f0ede8", textAlign: "right" }}>{fmt(item.preco * item.qtd)}</p>
                          }
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {carrinho.length > 0 && (
                <div style={{ marginBottom: 12 }}>
                  <p style={{ fontSize: 10, color: "#444", letterSpacing: 2, textTransform: "uppercase", marginBottom: 5 }}>Desconto (R$)</p>
                  <input className="field" type="number" placeholder="0,00" value={desconto} onChange={(e) => setDesconto(e.target.value)} style={{ fontSize: 13 }} />
                </div>
              )}

              <p style={{ fontSize: 10, color: "#444", letterSpacing: 2, textTransform: "uppercase", marginBottom: 7 }}>Pagamento</p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 5, marginBottom: 12 }}>
                {FORMAS.map((f) => (
                  <button key={f} className={`forma-btn ${forma === f ? "sel" : ""}`} onClick={() => setForma(f)}>{FORMA_ICON[f]} {f}</button>
                ))}
              </div>

              {forma === "Dinheiro" && (
                <div style={{ marginBottom: 12 }}>
                  <p style={{ fontSize: 10, color: "#444", letterSpacing: 2, textTransform: "uppercase", marginBottom: 5 }}>Valor recebido</p>
                  <input className="field" type="number" placeholder="0,00" value={dinheiroPago} onChange={(e) => setDinheiroPago(e.target.value)} />
                  {troco > 0 && <p style={{ fontSize: 15, fontWeight: 700, color: ACCENT, marginTop: 8, textAlign: "center" }}>Troco: {fmt(troco)}</p>}
                </div>
              )}

              <div style={{ borderTop: "1px solid rgba(255,255,255,0.06)", paddingTop: 12, marginBottom: 12 }}>
                {descontoVal > 0 && <>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "#555", marginBottom: 4 }}><p>Subtotal</p><p>{fmt(subtotal)}</p></div>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: RED, marginBottom: 6 }}><p>Desconto</p><p>-{fmt(descontoVal)}</p></div>
                </>}
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 22, fontWeight: 800 }}>
                  <p>Total</p><p style={{ color: GREEN }}>{fmt(total)}</p>
                </div>
              </div>

              <button className="btn" onClick={finalizar} style={{ width: "100%", background: carrinho.length > 0 ? `linear-gradient(135deg,${ACCENT},#ea580c)` : "rgba(255,255,255,0.05)", color: carrinho.length > 0 ? "#fff" : "#2a2a2a", padding: "14px 0", fontSize: 15, fontWeight: 700 }}>
                {carrinho.length > 0 ? "✓ Confirmar Pedido" : "Adicione itens"}
              </button>
            </div>
          </div>
        )}

        {/* ══ HISTÓRICO ══ */}
        {screen === "historico" && (
          <div className="fu">
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginBottom: 20 }}>
              {[
                { l: "Pedidos hoje", v: vendasHoje.length, cor: ACCENT },
                { l: "Faturado hoje", v: fmt(totalHoje), cor: GREEN },
                { l: "Total geral", v: fmt(vendas.reduce((s, v) => s + v.total, 0)), cor: "#555" },
              ].map(({ l, v, cor }) => (
                <div key={l} className="glass" style={{ padding: "16px 18px" }}>
                  <p style={{ fontSize: 9, color: "#444", letterSpacing: 2, textTransform: "uppercase", marginBottom: 8 }}>{l}</p>
                  <p style={{ fontFamily: "'Bebas Neue'", fontSize: 24, color: cor, letterSpacing: 1 }}>{v}</p>
                </div>
              ))}
            </div>
            {vendas.length === 0 && <p style={{ textAlign: "center", color: "#333", padding: 48, fontSize: 14 }}>Nenhum pedido registrado</p>}
            <div className="glass" style={{ overflow: "hidden" }}>
              {vendas.map((v, i) => {
                const d = new Date(v.data);
                return (
                  <div key={v.id} style={{ display: "flex", alignItems: "center", gap: 14, padding: "14px 18px", borderBottom: i < vendas.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none" }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 3 }}>
                        <p style={{ fontSize: 14, fontWeight: 600 }}>🏢 {v.cliente}</p>
                        <span style={{ fontSize: 10, background: "rgba(255,255,255,0.05)", color: "#555", padding: "2px 8px", borderRadius: 20 }}>{FORMA_ICON[v.forma]} {v.forma}</span>
                        {v.vencimento && <span style={{ fontSize: 10, color: ACCENT }}>venc. {v.vencimento}</span>}
                      </div>
                      <p style={{ fontSize: 11, color: "#3a3a3a" }}>{fmtDate(d)} {fmtTime(d)} · {v.itens.length} {v.itens.length === 1 ? "item" : "itens"}{v.obs ? ` · ${v.obs}` : ""}</p>
                    </div>
                    <p style={{ fontSize: 16, fontWeight: 700, color: GREEN }}>{fmt(v.total)}</p>
                    <button className="btn" onClick={() => setComprovante(v)} style={{ background: "rgba(255,255,255,0.05)", color: "#888", padding: "7px 12px", fontSize: 12 }}>🧾</button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ══ PRODUTOS ══ */}
        {screen === "produtos" && (
          <div className="fu">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <p style={{ fontSize: 13, color: "#555" }}>{produtos.length} produtos cadastrados</p>
              <button className="btn" onClick={() => setProdutoForm({ nome: "", preco: "", unidade: "un", categoria: "DTF Têxtil" })} style={{ background: ACCENT, color: "#fff", padding: "10px 18px" }}>+ Novo produto</button>
            </div>
            {["DTF Têxtil","DTF UV","Camisa Lisa"].map((cat) => {
              const lista = produtos.filter(p => p.categoria === cat);
              if (!lista.length) return null;
              return (
                <div key={cat} style={{ marginBottom: 20 }}>
                  <p style={{ fontSize: 10, color: CAT_COR[cat], letterSpacing: 3, textTransform: "uppercase", marginBottom: 10, fontWeight: 600 }}>{cat}</p>
                  <div className="glass" style={{ overflow: "hidden" }}>
                    {lista.map((p, i) => (
                      <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 14, padding: "12px 18px", borderBottom: i < lista.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none" }}>
                        <div style={{ flex: 1 }}>
                          <p style={{ fontSize: 14, fontWeight: 500 }}>{p.nome}</p>
                          <p style={{ fontSize: 11, color: "#333", marginTop: 2 }}>{p.unidade}</p>
                        </div>
                        <p style={{ fontSize: 16, fontWeight: 700, color: ACCENT }}>{fmt(p.preco)}<span style={{ fontSize: 10, color: "#333", marginLeft: 2 }}>/{p.unidade}</span></p>
                        <button className="btn" onClick={() => setProdutoForm({ ...p })} style={{ background: "rgba(255,255,255,0.05)", color: "#888", padding: "7px 12px", fontSize: 12 }}>✏️</button>
                        <button className="btn" onClick={() => { setProdutos((prev) => prev.filter((x) => x.id !== p.id)); showToast("Removido.", "erro"); }} style={{ background: "rgba(239,68,68,0.07)", color: RED, padding: "7px 10px", fontSize: 12 }}>✕</button>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* BOTTOM BAR */}
      <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, background: "#0c0c0f", borderTop: "1px solid rgba(255,255,255,0.05)", padding: "8px 0" }}>
        <div style={{ maxWidth: 940, margin: "0 auto", display: "flex", justifyContent: "center", gap: 4 }}>
          {[["💰","Financeiro",true],["🛒","Caixa",true],["📦","Estoque",false],["📋","Pedidos",false],["👥","Clientes",false]].map(([icon, label, done]) => (
            <div key={label} style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "4px 16px", borderRadius: 8, background: done ? "rgba(249,115,22,0.08)" : "transparent", opacity: done ? 1 : 0.2 }}>
              <span style={{ fontSize: 17 }}>{icon}</span>
              <p style={{ fontSize: 9, color: done ? ACCENT : "#444", letterSpacing: 1, marginTop: 2 }}>{label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
